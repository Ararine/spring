window.location.search

const url = new URL;
const urlParams = url.searchParmas;

 


