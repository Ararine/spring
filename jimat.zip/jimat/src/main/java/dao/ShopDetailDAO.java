package dao;

import java.util.List;
import dto.ShopDetailDTO;

public interface ShopDetailDAO {

	public ShopDetailDTO shopDetailData(String number);

}
