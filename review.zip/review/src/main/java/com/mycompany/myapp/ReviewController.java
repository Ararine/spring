package com.mycompany.myapp;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ReviewController {

	private ReviewService service;
	private ReviewDTO rdto;
	
	public ReviewController() {

	}
	
	public void setService(ReviewService service) {
		this.service = service;
	}
	
	//http://localhost:8090/myapp/test.do
	@RequestMapping(value="test.do", method=RequestMethod.GET)
	public ModelAndView check_list(ReviewDTO dto, ModelAndView mav) {
		System.out.println("find_review_allprocess : OK");
		List<ReviewDTO> alist = service.find_review_allprocess();

		List<String> alist_write_date = new ArrayList<String>();
		List<String> alist_update_date = new ArrayList<String>();
		
		for(ReviewDTO roll:alist) {
			String[] convert_list1 = roll.getReview_write_date().split("/");
			String[] convert_list2 = roll.getReview_update_date().split("/");
			alist_write_date.add(convert_list1[0] +"년 " + convert_list1[1] + "월 " + convert_list1[2] + "일");
			alist_write_date.add(convert_list2[0] +"년 " + convert_list2[1] + "월 " + convert_list2[2] + "일");			
		}
		
		mav.addObject("alist", alist);
		mav.addObject("alist_write_date", alist_write_date);
		mav.addObject("alist_update_date", alist_write_date);
		mav.setViewName("test");
		return mav;
	}
	
	//http:localhost:8090/myapp/reviewlist.do
	@RequestMapping(value="reviewlist.do", method=RequestMethod.GET)
	public String search_review_user( ) {
		return "review";
	}
	
	//http:localhost:8090/myapp/reviewlist2.do
	@RequestMapping(value="reviewlist2.do", method=RequestMethod.GET)
	public String search_review_number( ) {
		return "review2";
	}
	
	//http:localhost:8090/myapp/reviewlist.do
	@RequestMapping(value="reviewlist.do", method=RequestMethod.POST)
	public ModelAndView review_user_list(String review_writer_id, ReviewDTO dto, ModelAndView mav) {
		System.out.println("find_user_review");
//		System.out.println("review_writer_id :" +review_writer_id);
		List<ReviewDTO> aList = service.find_review_userprocess(review_writer_id);
//		System.out.println(aList);
		List<String> alist_write_date = new ArrayList<String>();
//		List<String> alist_update_date = new ArrayList<String>();
		
		for(ReviewDTO roll:aList) {
			String[] convert_list1 = roll.getReview_write_date().split("/");
//			String[] convert_list2 = roll.getReview_update_date().split("/");
			alist_write_date.add(convert_list1[0] +"년 " + convert_list1[1] + "월 " + convert_list1[2] + "일");
//			alist_write_date.add(convert_list2[0] +"년 " + convert_list2[1] + "월 " + convert_list2[2] + "일");			
		}
		
		mav.addObject("aList", aList);
		mav.addObject("alist_write_date", alist_write_date);
//		mav.addObject("alist_update_date", alist_write_date);
		mav.setViewName("review");
		return mav;
	}
	
	//http:localhost:8090/myapp/reviewlist2.do
	@RequestMapping(value="reviewlist2.do", method=RequestMethod.POST)
	public ModelAndView review_number(long review_number, ModelAndView mav, ReviewDTO dto) {
		System.out.println("find_review_number");
		ReviewDTO list_review_number = service.find_review_numberprocess(review_number);
		String alist_write_date = "";
		String[] convert_list1 = list_review_number.getReview_write_date().split("/");
//		String[] convert_list2 = roll.getReview_update_date().split("/");
		alist_write_date = convert_list1[0] +"년 " + convert_list1[1] + "월 " + convert_list1[2] + "일";
//		alist_write_date = convert_list2[0] +"년 " + convert_list2[1] + "월 " + convert_list2[2] + "일";			
		
		mav.addObject("list_review_number", list_review_number);
		mav.addObject("alist_write_date", alist_write_date);
//		mav.addObject("alist_update_date", alist_write_date);
		mav.setViewName("review2");
		return mav;
	}
	
	//http://localhost:8090/myapp/reviewform.do
	@RequestMapping(value="reviewform.do", method=RequestMethod.GET)
	public String review_write() {
		return "reviewform";
	}
	
	@RequestMapping(value="reviewwrite.do", method=RequestMethod.POST)
	public ModelAndView review_writePro(ReviewDTO dto, ModelAndView mav) {
		System.out.println("review_write");
		System.out.println("dto.review_content : " + dto.getReview_content());
		mav.addObject("dto", dto);
		mav.setViewName("review");
		return mav;
	}
}   
 